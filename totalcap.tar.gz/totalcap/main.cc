// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <stdint.h>
#include <string>
#include <vector>
#include <fstream>
#include <iterator>
#include <unordered_map>
#include <algorithm>
#include <list>
#include <unordered_set>
#include <sstream>
#include <cassert>
#include <numeric>
#include "console_msg.h"


uint16_t seed[64][3];

struct cap_edge_t
{

  int64_t n1;
  int64_t n2;
  float cap;
  
};


std::istream& operator>>(std::istream& is, cap_edge_t& c) {
  is >> c.n1 >> c.n2 >> c.cap;
  return is;
}

struct neighbor_node_t {
  size_t node_id;
  float cap;
  neighbor_node_t() = default;
  neighbor_node_t(size_t id, float c):
    node_id(id),
    cap(c) { }
  
};

std::ostream& operator << (std::ostream& os, const neighbor_node_t& n) {
  os << "id: " << n.node_id << " "
     << "cap: " << n.cap;
  return os;
}

struct neighbor_graph_t {
  
  uint64_t node_id;                // remapped id
  std::vector<neighbor_node_t> neighbors; // remapped id
  bool critical_net {false};

};

std::ostream& operator<<(std::ostream& os, const neighbor_graph_t& n) {
  os << "id: " << n.node_id << " "
     << "signal: " << n.critical_net << " "
     << "#neighbors: " << n.neighbors.size() << std::endl;
  os << "-- neighbors begin -- " << std::endl;
  for(auto& nn: n.neighbors) {
    os << nn << std::endl;
  }
  os << "-- neighbors end -- " << std::endl;
  return os;
}


std::vector<int64_t> get_critical_nets(const std::string& config) {

  std::ifstream ifs(config);
  std::string line;
  std::string option;
  while (std::getline(ifs, line)) {
    
    std::istringstream ss(line);
    ss >> option;
    if( option == "critical_nets:") {

      std::vector<int64_t> crit_nets ((std::istream_iterator<int64_t>(ss)),
                                      (std::istream_iterator<int64_t>()));
      
      
      return crit_nets;
      
    }
  }
  
  return std::vector<int64_t>();
}

size_t pick_next_hop(const neighbor_graph_t& curr_node,
                     size_t thread_id) {

  float rnd = erand48(seed[thread_id]);

  auto hop_next =
    std::find_if(curr_node.neighbors.begin(),
                 curr_node.neighbors.end(),
                 [rnd](const neighbor_node_t& n) {
                   return rnd < n.cap;
                 });
                               
  // incase of rounding error:
  if (hop_next == curr_node.neighbors.end()) {
    return curr_node.neighbors.back().node_id;
  }
  return hop_next->node_id;

}

size_t walk_to(size_t start_net,
               const std::vector<neighbor_graph_t>& graph,
               size_t thread_id ) {
  
  size_t next_hop = pick_next_hop(graph[start_net], thread_id);

  while (!graph[next_hop].critical_net /* && max_step_reached */) {
    next_hop = pick_next_hop(graph[next_hop], thread_id);
  }
  
  return next_hop;
  
}

std::vector<neighbor_graph_t>
build_walk_graph(const std::vector<cap_edge_t>& all_edges,
                 const std::unordered_set<uint64_t>& hop_terminal_set,
		 size_t total_nodes) {
  std::vector<neighbor_graph_t> graph(total_nodes);
  
  for (auto& e: all_edges) {
    assert(e.n1 < (int64_t)total_nodes);
    assert(e.n2 < (int64_t)total_nodes);
    
    graph[e.n1].node_id = e.n1;
    graph[e.n1].neighbors.emplace_back(e.n2, e.cap);
    if(hop_terminal_set.count(e.n1) == 1) {
      graph[e.n1].critical_net = true;
    }

    
    graph[e.n2].node_id = e.n2;
    graph[e.n2].neighbors.emplace_back(e.n1, e.cap);
    if(hop_terminal_set.count(e.n2) == 1) {
      graph[e.n2].critical_net = true;
    }
  }

  
  /// remove direct coupling
  for (auto& n: graph) {
    if (hop_terminal_set.count(n.node_id) == 1) {
      auto last =
        std::remove_if(n.neighbors.begin(),
                       n.neighbors.end(),
                       [&hop_terminal_set]
                       (const neighbor_node_t& to_net) {
                         return hop_terminal_set.count(to_net.node_id) == 1;
                       });
      
      n.neighbors.erase(last, n.neighbors.end());      
    }
  }
  
  return graph;
}

struct total_cap_t{
  size_t node_id;
  float total_cap;
};

std::unordered_map<size_t, float>
get_total_cap_for_signal(const std::vector<neighbor_graph_t>& graph,
                         const std::vector<size_t>& signals) {
  

  std::unordered_map<size_t, float> signal_tcap;

  for (auto& n: signals) {

    float tcap = std::accumulate(graph[n].neighbors.begin(),
                                     graph[n].neighbors.end(),
                                     0.f,
                                     [](float pre_sum, const neighbor_node_t& nn) {
                                       return pre_sum + nn.cap;
                                     });
    signal_tcap[n] += tcap;

  }

  return signal_tcap;
}

void update_walk_graph_prob (std::vector<neighbor_graph_t>& graph) {
  for(auto& n: graph) {
    // get total cap:
    float tcap =
      std::accumulate(n.neighbors.begin(),
                      n.neighbors.end(),
                      0.f,
                      [](float pre_sum, const neighbor_node_t& nn) {
                        return pre_sum + nn.cap;
                      });

    if( tcap <= 0.f) {
      ERROR("bad value: " << tcap);
      ERROR(n);

    }
    
    assert(tcap > 0.);
    // nomalized to 0~1:
    std::for_each(n.neighbors.begin(), n.neighbors.end(),
                  [tcap](neighbor_node_t& nn) {
                    nn.cap /= tcap;
                  });


    auto first = n.neighbors.begin();
    tcap = first->cap;
    ++first;
    for(; first != n.neighbors.end(); ++first){
      tcap += first->cap;
      first->cap = tcap;
    }
    

  }
}

int main(int argc, char *argv[])
{

  INFO("TotalCap Calculator for ICCAD Contest 2018");
  if ( argc < 4 ) {
    INFO("TotalCap <.cap file> <config file> <samples>");
    return -1;
  }
  
  std::string cap_file(argv[1]);
  std::string config_file(argv[2]);
  size_t samples = std::stoul(argv[3]);

  std::ifstream ifs(cap_file);
  INFO("Load critical nets...");
  std::vector<int64_t> crit_nets = get_critical_nets(config_file);

  if (crit_nets.size() == 0) {
    ERROR("failed to get critical nets!");
    return -1;
  }

  INFO("Critical Nets: --------------------------------------");
  std::copy(crit_nets.begin(),
            crit_nets.end(),
            std::ostream_iterator<int64_t>(std::cout, " "));
  std::cout << std::endl;
  

  
  INFO("Loading all edges ...");
  std::vector<cap_edge_t> all_edges((std::istream_iterator<cap_edge_t>(ifs)),
                                    (std::istream_iterator<cap_edge_t>()));
  INFO("OK");

  
  std::unordered_map<int64_t, size_t> node_id_map;
  std::unordered_map<size_t, int64_t> reverse_node_id_map;
  size_t node_id = 0;

  // remap node id:
  for (auto& e: all_edges) {
    
    if (node_id_map.count(e.n1) == 0) {
      node_id_map[e.n1] = node_id;
      reverse_node_id_map[node_id] = e.n1;
      e.n1 = node_id++;
    }else {
      e.n1 = node_id_map[e.n1];
      
    }

    if (node_id_map.count(e.n2) == 0) {
      node_id_map[e.n2] = node_id;
      reverse_node_id_map[node_id] = e.n2;
      e.n2 = node_id++;
    }else {
      e.n2 = node_id_map[e.n2];
    }
    
  }


  size_t total_nodes = node_id;
  INFO("Total #nodes : " << total_nodes);
  INFO("Verifying node mapping...");

  for(auto& i:node_id_map) {
    if( i.first != reverse_node_id_map[i.second]) {
      ERROR("Failed.");
      return -1;
    }
  }

  INFO("OK");
  INFO("ground id: 0 => " << node_id_map[0]);

  
  // convert crit nets:
  std::unordered_set<uint64_t> hop_terminal_set;

  for (auto& n: crit_nets) {
    
    if (node_id_map.count(n) == 0) {
      ERROR("no crit nets found in the design :" << n);
      return -1;
    }

    
    uint64_t mapped_id = node_id_map[n];
    hop_terminal_set.insert(mapped_id);
  }
  
  size_t gnd_node = node_id_map[0];
  hop_terminal_set.insert(gnd_node); // add ground node

  std::vector<size_t> hop_start(hop_terminal_set.begin(),
                                hop_terminal_set.end());

  INFO("Remapped signal ids: -----------------------------");
  std::copy(hop_start.begin(),
            hop_start.end(),
            std::ostream_iterator<size_t>(std::cout, " "));
  std::cout << std::endl;
  INFO("OK");
  
  INFO("Building graph....");
  std::vector<neighbor_graph_t> graph =
    build_walk_graph(all_edges, hop_terminal_set, total_nodes);
  INFO("OK");

  // verify graph
  INFO("Verify graph...");
  for(size_t id = 0; id < graph.size();  ++id) {

    if (id != graph[id].node_id) {
      ERROR(id << "====>" << graph[id].node_id);
      ERROR( graph[id] );
      return -1;
    }
    
    if (graph[id].neighbors.size() == 0) {
      ERROR("Verification failed. id = "  << id);
      ERROR( graph[id]);
      return -1;
    }
    
    if (graph[id].critical_net) {
      INFO( "net "<< id << " : critical net.");
    }
  }

  INFO("OK");

  
  std::unordered_map<size_t, float> signal_total_cap =
    get_total_cap_for_signal(graph, hop_start);
  
  // to accu distrution
  update_walk_graph_prob(graph);
  
  const size_t loop = samples;
  float all_cap = 0;
  size_t thread_id = 0;
  
  //  std::unordered_map<size_t, size_t> hit_map;
  INFO("Total Cap:");
  for(auto start_id: hop_start) {
    if(start_id == gnd_node) continue; // skip grund node;
    size_t hit_cn = 0;

    for(size_t i = 0; i < loop; ++i){
      
      size_t hit = walk_to(start_id,  graph, thread_id);

      if(hit != start_id) { ++hit_cn; }

    }

    //    std::cout << "Total neighbor hit: " << hit_cn << std::endl;
    float tcap_left = float(hit_cn)/float(loop);
    float tcap = tcap_left *signal_total_cap[start_id];
    //    std::cout << tcap_left << std::endl;
    INFO( "Net " << reverse_node_id_map[start_id] << " : "  << tcap );
    all_cap += tcap;
  }
  
  INFO("================================================================");
  INFO("Total cap : " << all_cap );
  
  return 0;
}
