// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __DESIGN_RULE__
#define __DESIGN_RULE__
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include "token_iterator.h"
namespace rule {
  
  int get_min_layer_id();
  void set_min_layer_id(int);
  int get_max_layer_id();
  void set_max_layer_id(int);
    
  
}

struct layer_rule
{
  int layer_id;
  std::string type;
  int min_width;
  int min_space;
  int max_width;
  float min_density;
  float max_density;
  layer_rule() = default;
  layer_rule(int l, std::string t, int w, int s, int mxw, float min_d, float max_d):
    layer_id(l),
    type(std::move(t)),
    min_width(w),
    min_space(s),
    max_width(mxw),
    min_density(min_d),
    max_density(max_d) {}

  void print_layer() const {
    std::cout << "layer " << layer_id << ": " 
	      << type << " " 
	      << min_width << " "
	      << min_space << " "
	      << max_width << " "
	      << min_density << " "
	      << max_density << std::endl;
  }

};

inline std::vector<layer_rule> load_rule(const std::string& rule_file) {
  std::ifstream ifs(rule_file);
  std::string line;
  std::vector<layer_rule> rules;
  while(std::getline(ifs, line)) {

    ns_token::const_token_iterator_t begin = ns_token::cbegin_token(line);
    ns_token::const_token_iterator_t end = ns_token::cend_token(line);

    if (begin != end) {
      int layer_id = std::stoi(*begin++);
      std::string type = *begin++;
      
      int min_width = std::stoi(*begin++);
      int min_space = std::stoi(*begin++);
      int max_width = std::stoi(*begin++);
      float min_density = std::stof(*begin++);
      float max_density = std::stof(*begin);
      rules.emplace_back(layer_id, type, min_width, min_space, max_width, min_density, max_density);
    }
  }

  ifs.close();

  return rules;
}

#endif	// __DESIGN_RULE__
