// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "cap.h"
#include "rule.h"



std::vector<LayerLayoutIndex>
build_layout_index(std::vector<rect_t>& layout) {
  
  int min_layer_id = rule::get_min_layer_id();
  int max_layer_id = rule::get_max_layer_id();

  std::vector<LayerLayoutIndex> layout_index;
  layout_index.reserve(max_layer_id - min_layer_id + 1);
  
  for (int i = min_layer_id; i <= max_layer_id; ++i) {

    std::vector<rect_t> rects = collect_rects_on_layer(i, layout);
    auto tree = GenericKDTree::make_tree(rects.begin(), rects.end());
    layout_index.emplace_back(std::move(rects), std::move(tree), i);
    
  }

  return layout_index;
}








int g_x_resolution = 2;
int g_y_resolution = 2;

void x_resolution(int r) { g_x_resolution = r; }
void y_resolution(int r) { g_y_resolution = r; }


int x_resolution() { return g_x_resolution; }
int y_resolution() { return g_y_resolution; }

