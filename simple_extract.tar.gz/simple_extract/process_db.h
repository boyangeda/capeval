// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __BYANG_12_03_JUN_05_2018_PROCESS_DB_H
#define __BYANG_12_03_JUN_05_2018_PROCESS_DB_H
#include <string>
#include <vector>
#include <utility>
#include <fstream>
#include "token_iterator.h"
#include <iostream>
#include <cassert>
#include <map>
#include "common.h"

struct process_table_t {
  
  enum table_scale {
    NO_SCALE,
    SCALE_DOWN,
    SCALE_UP
  };
  
  void set_name(std::string s) {
    table_name_ = std::move(s);
  }

  
  void add_index(double x) {
    index_.push_back(x);
  }


  
  void add_entry(double a, double b) {
    add_entry(std::make_pair(a, b));
  }

  void add_entry(std::pair<double, double> v) {
    entries_.push_back(v);
  }
  
  process_table_t() = default;



  process_table_t(const process_table_t& rhs) :
    table_name_(rhs.table_name_),
    index_(rhs.index_),
    entries_(rhs.entries_)
  {}

  
  process_table_t(process_table_t&& rhs):
    table_name_(std::move(rhs.table_name_)),
    index_(std::move(rhs.index_)),
    entries_(std::move(rhs.entries_)) {}


  const process_table_t& operator=(process_table_t&& rhs) {
    move_in(std::move(rhs));
    return *this;
  }
  
  const process_table_t& operator=(const process_table_t& rhs) {
    move_in(process_table_t(rhs));
    return *this;
  }
  
  double first_index() const { return index_.front(); }
  double last_index() const { return index_.back(); }


  std::pair<table_scale, std::pair<double, double>>
  query(double x) const {
    // linear search
    if (x < index_.front())
      return std::make_pair(SCALE_DOWN, entries_.front());
    if (x >= index_.back())
      return std::make_pair(SCALE_UP, entries_.back());
    
    auto it = index_.begin();
    ++it;
    while (*it < x) {
      ++it;
    }
    
    auto e_it = entries_.begin();
    e_it += std::distance(index_.begin(), it) - 1;
    
    assert(e_it != entries_.end());
    
    return std::make_pair(NO_SCALE, *e_it);
  }
  
  void print_index(std::ostream& os) const {

    os << "index : " ;
    std::for_each (index_.begin(), index_.end(), [&os](auto v) { os << v << " "; });
    os << std::endl;

  }
  void print_entries(std::ostream& os) const {
    os << "ENTRY: ";
    std::for_each (entries_.begin(), entries_.end(), [&os](auto& v) { os << "<"
								     << v.first
								     << ","
								     << v.second
								     << ">";});
    os << std::endl;

  }

  void print_table(std::ostream& os) const {
    os << "Table name: " << table_name_ << std::endl;
    print_index(os);
    print_entries(os);
  }

  const std::string& table_name() const {
    return table_name_;
  }

private:

  void move_in(process_table_t&& rhs) {
    
    table_name_ = std::move(rhs.table_name_);
    index_ = std::move(rhs.index_);
    entries_ = std::move(rhs.entries_);

  }
  
  std::string table_name_;
  std::vector<double> index_;
  std::vector<std::pair<double, double>> entries_;
  
};



inline process_table_t create_table(std::string table_name,
				    std::string index,
				    std::string value) {

  process_table_t p;
  //  std::cout << index << std::endl;
  auto idx_token_it = ns_token::cbegin_token(index);
  auto idx_token_end = ns_token::cend_token(index);

  for ( ; idx_token_it != idx_token_end; ++idx_token_it) {
    p.add_index(std::stod(*idx_token_it));
  }


  const std::string delim(")");
  const std::string delim2("(, "); 

  auto token_it = ns_token::cbegin_token(value, delim);
  auto token_end = ns_token::cend_token(value, delim);

  for( ; token_it != token_end; ++token_it) {

    std::string value_pair_s(*token_it);
    auto value_token = ns_token::cbegin_token(value_pair_s, delim2);
    double v1 = std::stod(*value_token);
    ++value_token;
    double v2 = std::stod(*value_token);
    p.add_entry(v1, v2);
  }

  p.set_name(std::move(table_name));
  //  p.print_table(std::cout);
  return process_table_t(std::move(p));

}


struct layer_process_table_t
{
  int layer_id;
  process_table_t area_cap_table_[24];
  process_table_t fringe_cap_table_[24];
  process_table_t lateral_table_;
  
};

enum TableType {
  AREA_TABLE,
  FRINGE_TABLE,
  LATERAL_TABLE
};


inline const process_table_t& get_table (int from_layer, 
					 int to_layer, 
					 TableType t, 
					 const std::vector<layer_process_table_t>& proc) {
  
  for (const auto & tbl: proc) {
    if (tbl.layer_id == from_layer) {


      switch (t) {
      
      case AREA_TABLE: 
	if(from_layer == to_layer) {
	  throw std::runtime_error("from layer and to layer are same!");
	}
	
	return tbl.area_cap_table_[to_layer];

      case FRINGE_TABLE:
	return tbl.fringe_cap_table_[to_layer];

      case LATERAL_TABLE:
	return tbl.lateral_table_;

      }
      
    }
  }
  // not found
  throw std::runtime_error("ERROR, no table found. ");
  return proc[0].area_cap_table_[0];
}






inline bool load_process_table(const std::string& proc_db,
                        int64_t& window,
                        std::vector<layer_process_table_t>& proc_tables ) {
  proc_tables.resize(24);

  std::ifstream ifs(proc_db);
  std::string s;
  std::vector<std::string> lines;
  const std::string delim(" \t:");  
  // load all lines
  while (std::getline(ifs, s) ) {

    if( comment_line(s) || empty_line(s)) continue;
    lines.emplace_back(std::move(s));
  }

  // dump effective lines:
  //  std::for_each(lines.begin(), lines.end(), [](std::string& line){ std::cout << line << std::endl;});
  //  return false;
  // load header matrix
  std::vector<std::string> mtx_hdr; 
  for(auto& l: lines) {

    auto token_it = ns_token::cbegin_token(l, delim);
    auto end_token = ns_token::cend_token(l, delim);
    if (token_it != end_token) {
      
      const std::string token1 = *token_it;

      if (token1 == "window") {
        ++token_it;
        window = std::stol(*token_it);
        continue;
      }

      // skip header
      ++token_it;
      if( token1 == "1" && *(token_it) == "2") {
	l.clear();		// clear header
	continue;
      }
      if ((token1 == "0" ||
	   token1 == "1" ||
	   token1 == "2" ||
	   token1 == "3" ||
	   token1 == "4" ||
	   token1 == "5" ||
	   token1 == "6" ||
	   token1 == "7" ||
	   token1 == "8" ||
	   token1 == "9") && *(token_it.char_begin()) == '(' ) {
	mtx_hdr.emplace_back( std::move(l) );
      }
    }
  }
  
  // dump mtx_hdr:
  // std::for_each(mtx_hdr.begin(), mtx_hdr.end(), [](const std::string& h){ std::cout << h << std::endl;});
  // return false;
  // load tables & map tables
  std::vector<std::string> table;
  std::map<std::string, process_table_t> name_table_map;

  std::string table_name;
  std::string index_line;
  std::string value_line;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    if (it->size() > 0) {

      auto token_it = ns_token::cbegin_token(*it, delim);
      auto end_token = ns_token::cend_token(*it, delim);

      const std::string token1 = *token_it;
      if (token1 == "TableName") {
	
	++token_it;
	table_name = *token_it;
	it->clear();
	++it;

	//skip comment/empty lines
	while( it != lines.end() && (empty_line(*it) || comment_line(*it)) )
	  ++it;

	if (it == lines.end()) {
 	  throw std::runtime_error("bad file format.");
	}
	
	index_line = std::move(*it);
	++it;

	// skip comment/empty lines
	while( it != lines.end() && (empty_line(*it) || comment_line(*it)) )
	  ++it;
	
	if (it == lines.end()) {
 	  throw std::runtime_error("bad file format.");
	}

	value_line = std::move(*it);
	process_table_t p = create_table(table_name, 
					 std::move(index_line), 
					 std::move(value_line));

	name_table_map[table_name] = std::move(p);

      }

    }
  }

  //  std::cout << "---------------------OK---------------" << std::endl;
  // relink tables:
  //  std::for_each(name_table_map.begin(), name_table_map.end(), [](auto & v) {v.second.print_table(std::cout);});


  const std::string delim1 = ")";
  const std::string token_spliter = " (,\t";

  for(auto& l: mtx_hdr) {
    // skip empty or comment lines
    if(empty_line(l) || comment_line(l)) { continue;}



    auto token_it = ns_token::cbegin_token(l, delim1);
    auto end_token = ns_token::cend_token(l, delim1);

    int from_layer_id = 1;    
    int to_layer_id = -1;
    //    std::cout << "table: " << l << std::endl;

    for (; token_it != end_token; ++token_it) {

      const std::string token = *token_it;
      //      std::cout << "token: " << token << std::endl;
      auto v_it = ns_token::cbegin_token(token, token_spliter);
      auto v_it_end = ns_token::cend_token(token, token_spliter);
      //first token
      if(from_layer_id == 1) {

	to_layer_id = std::stoi(*v_it);
	++v_it;
      }
      std::string area_table = *v_it;
      ++v_it;
      std::string fringe_table = *v_it;
      assert(to_layer_id >=0);
      assert(to_layer_id <=9);

      /* std::cout << "from: "<< from_layer_id  */
      /* 		<< " to: " <<to_layer_id  */
      /* 		<< " area_tbl: " << area_table  */
      /* 		<< " finge_tbl: " << fringe_table */
      /* 		<< std::endl; */

      proc_tables[from_layer_id].layer_id = from_layer_id;
      if(from_layer_id != to_layer_id) {
	//	name_table_map[area_table].print_table(std::cout);
	proc_tables[from_layer_id].area_cap_table_[to_layer_id] = name_table_map[area_table];
	//	name_table_map[fringe_table].print_table(std::cout);
	proc_tables[from_layer_id].fringe_cap_table_[to_layer_id] = 
	  name_table_map[fringe_table];
      }else{
	proc_tables[from_layer_id].lateral_table_ = name_table_map[fringe_table];
      }
      
      ++from_layer_id;
    }

  }
  return true;
}
#endif /* __BYANG_12_03_JUN_05_2018_PROCESS_DB_H */

