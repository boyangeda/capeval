// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <string>
#include <fstream>
#include "config_parser.h"
#include "process_db.h"
#include "rule.h"
#include "rect.h"
#include "area_cap.h"
#include "fringe_cap.h"
#include "lateral_cap.h"
#include "mt.h"
#include <unistd.h>
#include "console_msg.h"
#include "copyright.h"



void remap_fill_net_id(std::vector<rect_t>& fill, int64_t start_id) {
  for(auto& r: fill) {
    r.rect_id = start_id;
    r.net_id = -start_id;
    ++start_id;
  }
}

void usage() {
  std::cout << "Usage: <config> [#thread, default = 1] "
	    << "[x resolution, default = 2] [y resolution, default = 2] " << std::endl;
}


int main(int argc, char *argv[])
{

  INFO("Simple Cap Extractor 0.1 for ICCAD Contest 2018");
  INFO("Nov. 22, 2018");
  INFO("This program is free software: you can redistribute it and/or ");
  INFO("modify it under the terms of the GNU General Public License as ");
  INFO("published by the Free Software Foundation, either version 3 of ");
  INFO("the License, or (at your option) any later version.");

  INFO("This program is distributed in the hope that it will be useful,");
  INFO("but WITHOUT ANY WARRANTY; without even the implied warranty of ");
  INFO("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the ");
  INFO("GNU General Public License for more details.");

  ns_config::Config conf;
  if( argc < 2 ) {
    usage();
    return -1;
  }


  ThreadSetting::set_thread_count(1);

  if (argc >= 3) {		// thread count
    
    uint32_t thread_cn = std::stoul(argv[2]);
    ThreadSetting::set_thread_count(thread_cn);
    
  }

  ThreadSetting::init_rand_seed();
  if (argc >= 4) {		// x res
    
    int res = std::stoi(argv[3]);
    x_resolution(res);

  }

  if (argc >= 5) {		// y res
    
    int res = std::stoi(argv[4]);
    y_resolution(res);


  }


  std::string banner(70, '-');
  INFO(banner);

  
  INFO("Config file : " << argv[1]);
  INFO("X resolution: " << x_resolution());
  INFO("Y resolution: " << y_resolution());
  INFO("#thread(s)  : " << ThreadSetting::thread_count());
  INFO("#CPU Core(s): " << sysconf(_SC_NPROCESSORS_ONLN));


  INFO(banner);
  


  INFO("Loading config file " << argv[1]);
  try {
    conf = ns_config::load_config(argv[1]);
  }catch(std::exception& e) {
    
    ERROR(e.what());
    return -1;
    
  }
  
  INFO("OK");  
  
  // rules
  INFO("Loading design rules "<< conf.rule_);
  std::vector<layer_rule> rules = load_rule(conf.rule_);
  INFO("OK");
  

  // process tables

  INFO("Loading process tables "<<conf.process_db_);
  int64_t window = 0;
  std::vector<layer_process_table_t> proc_tables;
  load_process_table (conf.process_db_, window, proc_tables);
  INFO("OK");


  // load fills
  std::vector<rect_t> fill_rects;
  if (conf.fill_data_.size() > 0) {
    INFO("Loading fills from " << conf.fill_data_);
  
    std::ifstream ifs(conf.fill_data_);
    std::vector<rect_t> fills((std::istream_iterator<rect_t>(ifs)),
                              (std::istream_iterator<rect_t>()));
    INFO("OK");
    INFO( fills.size() << " fills loaded.");
    fill_rects.swap(fills);
    ifs.close();
  }

  

  // import design
  INFO("Loading design " << conf.input_design_);
  std::ifstream design_fs(conf.input_design_);
  
  // get design boundary
  std::string boundary_line;
  std::getline(design_fs, boundary_line);
  
  std::vector<rect_t> design_rects((std::istream_iterator<rect_t>(design_fs)),
                                   (std::istream_iterator<rect_t>()));

  INFO("OK");
  INFO(design_rects.size() << " rectangle(s) loaded.");
  
  // remap fill ids
  remap_fill_net_id(fill_rects, design_rects.size() + 1);

  // merge
  INFO("Merging design and fill");
  design_rects.insert(design_rects.end(),
                      fill_rects.begin(),
                      fill_rects.end());

  INFO("OK");

  INFO("Building layout index...");
  std::vector<LayerLayoutIndex> indexed_layout =
    build_layout_index(design_rects);
  INFO("OK");
  
  std::unordered_map<NetPair, double> caps;

  
  // extract area cap
  INFO("Extacting area cap...");
  extract_area_cap(indexed_layout,
  		   caps,
  		   proc_tables);
  INFO("Done area caps");


  // extract lateral cap
  INFO("Extracting lateral cap...");
  extract_lateral_cap(indexed_layout, caps, proc_tables);
  INFO("Done lateral caps.");

  // extract fringe cap
  INFO("Extracting fringe cap...");
  extract_fringe_cap(indexed_layout, caps, proc_tables);
  INFO("Done fringe caps.");

  
  // dump results
  std::string cap_file = conf.input_design_ + ".cap";
  std::ofstream ofs(cap_file);
  
  INFO("Output results into " << cap_file);
  if(!ofs) {
    ERROR("cannot create output file " << cap_file);
    return -1;
  }

  
  // write all:
  for(auto& c: caps) {
    // filter all same-net cap:
    if (c.first.first != c.first.second) {
      ofs << c.first.first <<" " << c.first.second << "  " << c.second << std::endl;
    }
  }
  
  INFO("OK");
  INFO("All caps are written into  " << cap_file);

  return 0;
  
}

