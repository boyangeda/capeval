// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <math.h>
#include "area_cap.h"
#include <thread>
#include "mt.h"
#include <atomic>
#include "console_msg.h"

bool extract_area_cap(const std::vector<LayerLayoutIndex>& layout_index,
		      std::unordered_map<NetPair, double>& caps,
		      std::vector<layer_process_table_t>& proc) {


  constexpr size_t thread_thres = 512; // 0.5k
  size_t layer_extracted = 0;
  
  for (auto& l: layout_index) {
    INFO("Extracting polyons on layer " << l.get_layer() << "...");



    size_t total_r = l.get_layout().size();
    INFO("Total " << total_r << " rectangles on layer " << l.get_layer());
    
    if (total_r < thread_thres ||
	ThreadSetting::thread_count() == 1) {
      WARN("Using single-thread extraction.");
      for (auto& r: l.get_layout()) {
	extract_area_cap(r, layout_index, caps, proc);
      }
    } else {
      INFO("Using multi-thread extraction");
      
      std::unordered_map<NetPair, double> area_caps[64]; // at most 64 thread;
      std::thread thread[64];

      auto const& layout = l.get_layout();

      size_t avg_ele = total_r / ThreadSetting::thread_count();

      std::atomic<size_t>  extracted;
      extracted.store(0);
      auto begin = layout.begin();

      size_t thread_id = 0; 
      for (;thread_id < ThreadSetting::thread_count() - 1;  ++thread_id) {

	auto end = begin + avg_ele;
	thread[thread_id] =
	  std::thread([begin,
		       end,
		       &layout_index,
		       &area_caps,
		       thread_id,
		       &proc,
		       &extracted]() {

			size_t extract_local = 0;

			for (auto start = begin; start != end; ++start) {

			  extract_area_cap(*start, layout_index, area_caps[thread_id], proc);
			  ++ extract_local;
			}
			extracted += extract_local;

		      });

	begin = end;

      }
      
      // last thread:

      auto end = layout.end();
      assert(thread_id == ThreadSetting::thread_count() - 1);
      
      thread[thread_id] =
	std::thread([begin,
		     end,
		     &layout_index,
		     &area_caps,
		     thread_id,
		     &proc,
		     &extracted]() {

		      size_t extract_local = 0;

		      for (auto start = begin; start != end; ++ start) {

			extract_area_cap(*start, layout_index, area_caps[thread_id], proc);
			++ extract_local;
		      }
		      extracted += extract_local;

		    });


      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	thread[i].join();
      }

      if(total_r != extracted.load()) {
	ERROR("some rects are skiped");
	exit(-1);
      }     
      // save results:
      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	for(auto& c: area_caps[i]) {
          
          if(c.second < 0.) {
            WARN("Negative area cap found!");
          }
	  caps[c.first] += c.second;
	}
      }

      
    }
    
    ++layer_extracted;
    INFO("OK");
    
  }
  return true;
}

double calculate_area_cap_helper(double overlap_area, 
				 int from_layer,
				 int to_layer,
				 const process_table_t& area_tbl) {

#ifdef AREA_SAMPLE_DEBUG
  float idex[]={1.001, 0.9999, 1.0001, 1.0001, 1.001};
  if(from_layer == 3 && to_layer == 2) {
    std::cout << "3-2 area: " << overlap_area << std::endl;
  }
  return overlap_area*idex[to_layer];
#endif
  auto table_point = area_tbl.query(overlap_area);
  double area_cap = 0;
#ifdef DEBUG_AREA_CAP
  std::cout << " area = " << overlap_area
	    << " from layer: "<< from_layer
	    << " to layer: " << to_layer << std::endl;
  std::cout << " Tbl name: " << area_tbl.table_name() << std::endl;
  std::cout << " table point: "<< table_point.second.first
	    <<" " << table_point.second.second << std::endl;
#endif
  switch (table_point.first) {

  case process_table_t::NO_SCALE:
    area_cap = (table_point.second.first*overlap_area + table_point.second.second) * overlap_area;
    break;

  case process_table_t::SCALE_DOWN:
    {
      const double first_index = area_tbl.first_index();
      const double scale_factor = overlap_area/first_index;
      area_cap = (table_point.second.first*first_index + table_point.second.second)*first_index;
      area_cap *= scale_factor;
    }
    break;
  case process_table_t::SCALE_UP:
    {
      const double last_index = area_tbl.last_index();
      const double scale_factor = overlap_area/last_index;
      area_cap = (table_point.second.first*last_index + table_point.second.second)*last_index;
      area_cap *= scale_factor;
    }

    break;
  }

  
  return area_cap;

}

bool hit_any_rect(double x, double y, const std::vector<rect_t>& rects, int64_t& to_net_id)  {

  for(auto& r:  rects) {
    if (r.enclose(x, y)) {
      to_net_id = r.net_id;
      return true;
    }
  }

  return false;
}


const rect_t* hit_any_target(double x, double y,
			     const std::vector<rect_t>& rects)  {

  for(auto& r:  rects) {
    
    if (r.enclose(x, y)) {
      return &r;
    }
    
  }

  return nullptr;
  
}

const rect_t* hit_any_target(int64_t x, int64_t y,
			     const std::vector<rect_t>& rects)  {

  for(auto& r:  rects) {
    
    if (r.enclose(x, y)) {
      return &r;
    }
    
  }

  return nullptr;
  
}

std::pair<double, double> create_sample_point_for(const rect_t& r, size_t thread_id) {
  
  const double w = r.x2 - r.x1;
  const double h = r.y2 - r.y1;

  double x = w*erand48(ThreadSetting::rand_seed(thread_id)) + r.x1;
  double y = h*erand48(ThreadSetting::rand_seed(thread_id)) + r.y1;

  return std::make_pair(x, y);
}

const rect_t* hit_a_rect(double x, double y, int start_layer,
			 const std::vector<rect_t>* const layered_targets) {
  
  while (start_layer >= 0) {
    
    if (const rect_t* tgt =
	hit_any_target (x, y, layered_targets[start_layer])) {
      return tgt;
    }

    // nothing on this layer, move to the next layer
    --start_layer;
  }

  // didn't hit anything, something is wrong!
  abort();
  return nullptr;
  
}


const rect_t* hit_a_rect(int64_t x, int64_t y, int start_layer,
			 const std::vector<rect_t>* const layered_targets) {
  
  while (start_layer >= 0) {
    
    if (const rect_t* tgt =
	hit_any_target (x, y, layered_targets[start_layer])) {
      return tgt;
    }

    // nothing on this layer, move to the next layer
    --start_layer;
  }

  // didn't hit anything, something is wrong!
  abort();
  return nullptr;
  
}

bool sample_area(const rect_t& r,
		 std::vector<rect_t>* hit_targets,
		 std::unordered_map<NetPair, double> hit_map[24],
		 size_t samples,
		 size_t thread_id) {
  
  for (size_t i = 0; i < samples; ++i) {
      
    double x = 0, y = 0;
    std::tie(x,y) = create_sample_point_for(r, thread_id);

    int to_layer = r.layer_id - 1; // start from layer below:

    const rect_t* hit_rect = hit_a_rect(x, y, to_layer, hit_targets);
    assert(hit_rect != nullptr);
    if( r.net_id != hit_rect->net_id) {
      hit_map[hit_rect->layer_id][std::make_pair(r.net_id, hit_rect->net_id)] += 1.;
    }
    
  }

  return true;
}

size_t static_sample_area(const rect_t& r,
			std::vector<rect_t>* hit_targets,
			std::unordered_map<NetPair, double> hit_map[24],
			int x_resolution,
			int y_resolution) {
  size_t total_samples = 0;
  for(int64_t y = r.y1;  y <= r.y2; y+= y_resolution) {
    for(int64_t x = r.x1; x <= r.x2; x+= x_resolution) {

      int to_layer = r.layer_id - 1; // start from layer below:

      const rect_t* hit_rect = hit_a_rect(x, y, to_layer, hit_targets);
      assert(hit_rect != nullptr);

      if( r.net_id != hit_rect->net_id) {
	hit_map[hit_rect->layer_id][std::make_pair(r.net_id, hit_rect->net_id)] += 1.;
      }
      
      ++total_samples;

    }
  }


  return total_samples;
}


size_t  target_count(std::vector<rect_t>* overlaps_polygons, int start_layer) {
  size_t cnt = 0;
  for(int i = 0; i < start_layer; ++i) {
    cnt += overlaps_polygons[i].size();
  }

  return cnt;
}
bool sample_area_cap (const rect_t& r,
                      std::vector<rect_t>* overlaps_polygons, 
		      std::unordered_map<NetPair, double>& caps,
                      std::vector<layer_process_table_t>& proc,
		      size_t thread_id) {


  

  double total_samples = 0;
  
  double rect_area = area_of(r);
  
  


  // overlaps to polyons on a certain layer, and a certain net
  std::unordered_map<NetPair, double> area_map[24];
  
  // use static sample
  total_samples = static_sample_area(r, 
				     overlaps_polygons, 
				     area_map,
				     x_resolution(),
				     y_resolution());

  for (int i = 0; i < r.layer_id; ++i) {
    for (auto& am: area_map[i]) {
      // first is net pair, second is overlapped area
	
      double area = am.second/total_samples*rect_area;
      const process_table_t& area_tbl = get_table( r.layer_id, i,
						   AREA_TABLE, proc);

#ifdef DEBUG_AREA_CAP
      std::cout << "check area table : " << area_tbl.table_name()
		<< " from layer " << r.layer_id
		<< " to layer " << i
		<< " with area = " << area << std::endl;
#endif
      double cap_val =
	calculate_area_cap_helper(area, r.layer_id, i, area_tbl);


      if (cap_val < 0) {
        std::cout << "Negative cap found: " << cap_val << std::endl;

        std::cout << "check area table : " << area_tbl.table_name()
                  << " from layer " << r.layer_id
                  << " to layer " << i
                  << " with area = " << area << std::endl;

      }

#ifdef DEBUG_AREA_CAP
      std::cout << "area cap = " << cap_val << std::endl;
#endif
      caps[am.first] += cap_val;
      //        total_cap += cap_val;
    }
  }
  return true;
}

bool extract_area_cap (const rect_t& r, 
		       const std::vector<LayerLayoutIndex>& layout, 
		       std::unordered_map<NetPair, double>& caps,
		       std::vector<layer_process_table_t>& proc,
		       size_t thread_id) {

  assert(r.layer_id > 0);
  
  // layer one : get cap by area
  if (r.layer_id == 1) {
    
    const process_table_t& area_tbl = get_table( r.layer_id, 0, AREA_TABLE, proc);
    double area = area_of(r);
    #ifdef DEBUG_AREA_CAP
      std::cout << "check area table : " << area_tbl.table_name()
		<< " from layer " << r.layer_id
		<< " to layer " << 0
		<< " with area = " << area << std::endl;
#endif

    double cap_val =
      calculate_area_cap_helper(area, r.layer_id, r.layer_id - 1, area_tbl);
    
#ifdef DEBUG_AREA_CAP
      std::cout << "area cap = " << cap_val << std::endl;
#endif

    // update coupling r.net_id to ground
    caps[ std::make_pair(r.net_id, 0) ] += cap_val;
    return true;
    
  } else {
    std::vector<rect_t> overlaps[24]; // hard-coded!!!
  

    for( const auto& l: layout) {

      const int layer = l.get_layer();
      assert(layer >= 0);
      if (layer < r.layer_id)  { // below
	overlaps[layer] = l.QueryOverlap(r);
      }
    }
      //create fake polygons on layer 0
    overlaps[0].push_back(r);	// to guarantee it hit ground plane!
    overlaps[0][0].layer_id = 0;
    overlaps[0][0].net_id = 0;


    sample_area_cap (r, overlaps, caps, proc, thread_id);

  }
  
  return true;
  
}

