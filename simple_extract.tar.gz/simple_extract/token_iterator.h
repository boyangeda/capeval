// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __STRING_TOKEN_ITERATOR__
#define __STRING_TOKEN_ITERATOR__
#include <string>
#include <iterator>
#include <algorithm>
#include <utility>

namespace  ns_token {
  
  struct token_iterator_t : 
    public std::iterator<std::forward_iterator_tag, std::string>
  {

    typedef std::string::iterator char_iterator;
    typedef std::string::const_iterator const_char_iterator;
    
    token_iterator_t() = default;
    
    token_iterator_t(std::string::iterator begin, 
		     std::string::iterator end,
		     std::string delim) : 
      token_begin_(std::move(begin)),
      string_end_(std::move(end)),
      delim_(std::move(delim)) 
    {
      token_end_ = token_begin_;
      move_forward();
    }


    token_iterator_t(const token_iterator_t& rhs):
      token_begin_(rhs.token_begin_),
      token_end_(rhs.token_end_),
      string_end_(rhs.string_end_),
      delim_(rhs.delim_) {}

    
    token_iterator_t operator++(int) {
      token_iterator_t tmp(*this);
      move_forward();
      return tmp;
    }

    token_iterator_t operator++() {
      move_forward();
      return *this;

    }


    bool operator==(const token_iterator_t& rhs) const {
      return (token_begin_ == rhs.token_begin_ &&
	      token_end_ == rhs.token_end_);
    }


    bool operator!=(const token_iterator_t& rhs) const {
      return !(this->operator==(rhs));
    }

    // to do:  add function to return a string_view 
    
    std::string operator*() const {
      return std::string(token_begin_, token_end_);
    }

    char_iterator char_begin() const { return token_begin_; }
    char_iterator char_end() const { return token_end_; }

    std::pair<char_iterator, char_iterator> char_range_iterator() const {
      return std::make_pair(token_begin_, token_end_);
    }
  private:

    void move_forward() {
      const std::string& delim_cap = delim_;
      // forward-find none-token char:
      token_begin_ = 
	std::find_if(token_end_, 
		     string_end_, 
		     [&delim_cap](char c) 
		     {return delim_cap.find(c) == std::string::npos;});

      // forward-find token char:
      token_end_ = 
	std::find_if(token_begin_, string_end_, 
		     [&delim_cap](char c) 
		     {return delim_cap.find(c) != std::string::npos;});
      
    }
    

    bool is_delimiter(char c) const {
      for(auto d: delim_) {
	if(d == c) return true;
      }
      return false;
    }
    


    std::string::iterator token_begin_;
    std::string::iterator token_end_;
    std::string::iterator string_end_;
    std::string delim_;

  };


  struct const_token_iterator_t : 
    public std::iterator<std::forward_iterator_tag, std::string>
  {


    typedef std::string::const_iterator const_char_iterator;
    
    const_token_iterator_t() = default;
    
    const_token_iterator_t(std::string::const_iterator begin, 
			   std::string::const_iterator end,
			   std::string delim) : 
      token_begin_(std::move(begin)),
      string_end_(std::move(end)),
      delim_(std::move(delim)) 
    {
      token_end_ = token_begin_;
      move_forward();
    }


    const_token_iterator_t(const const_token_iterator_t& rhs):
      token_begin_(rhs.token_begin_),
      token_end_(rhs.token_end_),
      string_end_(rhs.string_end_),
      delim_(rhs.delim_) {}

    
    const_token_iterator_t operator++(int) {
      const_token_iterator_t tmp(*this);
      move_forward();
      return tmp;
    }

    const_token_iterator_t operator++() {
      move_forward();
      return *this;

    }

    // token_iterator_t operator--(int) {
    //   token_iterator_t tmp(*this);
    //   move_backward();
    //   return tmp;
    // }

    // token_iterator_t operator--() {

    //   move_backward();
    //   return *this;
    // }

    bool operator==(const const_token_iterator_t& rhs) const {
      return (token_begin_ == rhs.token_begin_ &&
	      token_end_ == rhs.token_end_);
    }


    bool operator!=(const const_token_iterator_t& rhs) const {
      return !(this->operator==(rhs));
    }

    // to do:  add function to return a string_view 
    
    std::string operator*() const {
      return std::string(token_begin_, token_end_);
    }

    const_char_iterator char_begin() const { return token_begin_; }
    const_char_iterator char_end() const { return token_end_; }

    std::pair<const_char_iterator, const_char_iterator> char_range_iterator() const {
      return std::make_pair(token_begin_, token_end_);
    }


  private:

    void move_forward() {
      const std::string& delim_cap = delim_;
      // forward-find none-token char:
      token_begin_ = 
	std::find_if(token_end_, 
		     string_end_, 
		     [&delim_cap](char c) 
		     {return delim_cap.find(c) == std::string::npos;});

      // forward-find token char:
      token_end_ = 
	std::find_if(token_begin_, string_end_, 
		     [&delim_cap](char c) 
		     {return delim_cap.find(c) != std::string::npos;});
      
    }
    



    std::string::const_iterator token_begin_;
    std::string::const_iterator token_end_;
    std::string::const_iterator string_end_;
    std::string delim_;

  };


  inline token_iterator_t begin_token(std::string& str, const std::string& delim = " \t\n\r") {
    return token_iterator_t(std::begin(str), std::end(str), delim);
  }
  inline token_iterator_t end_token(std::string& str, const std::string& delim = " \t\n\r") {
    return token_iterator_t(std::end(str), std::end(str), delim);
  }

  inline const_token_iterator_t cbegin_token(const std::string& str, 
					     const std::string& delim = " \t\n\r") {
    return const_token_iterator_t(std::begin(str), std::end(str), delim);
  }
  inline const_token_iterator_t cend_token(const std::string& str, 
					   const std::string& delim = " \t\n\r") {
    return const_token_iterator_t(std::end(str), std::end(str), delim);
  }
  

}
#endif
