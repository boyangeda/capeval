// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "lateral_cap.h"
#include "fringe_cap.h"
#include <math.h>
#include <thread>
#include "mt.h"
#include <atomic>
#include "console_msg.h"

bool extract_lateral_cap (const rect_t& r, 
			  const LayerLayoutIndex& layout, 
			  std::unordered_map<NetPair, double>& caps,
			  const process_table_t& lat_tbl,
			  size_t thread_id = 0) {
  
  // build same-layer seaching box

  int64_t max_distance = lat_tbl.last_index() + 0.5;

  // search right
  rect_t window =
    create_directional_search_window(r, max_distance, extract_xplus_dir_type());

  
  std::vector<rect_t> lat_neighbors = layout.QueryOverlap(window);

  if( lat_neighbors.size() > 0 ) {
    std::sort(lat_neighbors.begin(),
              lat_neighbors.end(), SortDirectionalType<extract_xplus_dir_type>());


    directional_side_cap_extract<extract_xplus_dir_type>(r, 
							 lat_neighbors, 
							 caps, 
							 lat_tbl, thread_id);
  }




  // swith to vertical direction:
  window = 
    create_directional_search_window(r, max_distance, extract_yplus_dir_type());



  lat_neighbors = layout.QueryOverlap(window);
  if (lat_neighbors.size() > 0){
    std::sort(lat_neighbors.begin(), lat_neighbors.end(), 
	      SortDirectionalType<extract_yplus_dir_type>());

    directional_side_cap_extract<extract_yplus_dir_type>(r, 
							lat_neighbors, 
							caps, 
							 lat_tbl, 
							 thread_id);

  }

  return true;
}


bool extract_lateral_cap (const std::vector<LayerLayoutIndex>& layout, 
			  std::unordered_map<NetPair, double>& caps,
			  std::vector<layer_process_table_t>& proc) {


  constexpr size_t thread_thres = 512; // 0.5k

  for(const auto& l: layout) {
    
    INFO("Extracting lateral cap on layer " << l.get_layer() << " ...");
    const process_table_t& lat_tbl = get_table(l.get_layer(), 0, LATERAL_TABLE, proc);
    
    size_t total_r = l.get_layout().size();
    INFO("Total " << total_r << " polygons on layer " << total_r);
    

    if (total_r < thread_thres || ThreadSetting::thread_count() == 1) {	
      // few rects, no need threading...
      WARN("Single-thread extraction.");
      for(auto& r: l.get_layout()) {
	extract_lateral_cap(r, l, caps, lat_tbl);
      }

    } else {
      INFO("Multi-thread extractin.");
      // multi threading
      std::unordered_map<NetPair, double> rlt_caps[64]; // at most 64 thread;
      std::thread thread[64];

      auto const& layout = l.get_layout();

      size_t avg_ele = total_r / ThreadSetting::thread_count();

      std::atomic<size_t>  extracted;
      extracted.store(0);
      auto begin = layout.begin();

      size_t thread_id = 0; 
      for (;thread_id < ThreadSetting::thread_count() - 1;  ++thread_id) {

	auto end = begin + avg_ele;

	thread[thread_id] = 
	  std::thread([begin, end, &l, &rlt_caps, thread_id, &lat_tbl, &extracted](){
	      size_t extract_local = 0;
	      for(auto start = begin; start != end; ++start) {
		extract_lateral_cap(*start, l, rlt_caps[thread_id], lat_tbl, thread_id);
		++ extract_local;
	      }
	      extracted += extract_local;
	    });
	begin = end;
      }

      // last thread
      auto end = layout.end();
      assert(thread_id == ThreadSetting::thread_count() - 1);

      thread[thread_id] = 
	std::thread([begin, end, &l, &rlt_caps, thread_id, &lat_tbl, &extracted](){
	    size_t extract_local = 0;
	    for(auto start = begin; start != end; ++start) {
	      extract_lateral_cap(*start, l, rlt_caps[thread_id], lat_tbl, thread_id);
	      ++extract_local;
	    }
	    extracted += extract_local;
	  });

      
      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	thread[i].join();
      }

      if(total_r != extracted.load()) {
	ERROR("some rects are skiped.");
	exit(-1);
      }     
      // save results:
      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	for(auto& c: rlt_caps[i]) {
	  caps[c.first] += c.second;
	}
      }

    }
    INFO("OK");
  }
  
  return true;
}
