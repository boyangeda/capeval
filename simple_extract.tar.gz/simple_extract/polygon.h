// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __RECT_H__
#define __RECT_H__
#include <stdint.h>
#include <vector>
#include <fstream>
#include <iterator>
#include <string>
#include "common.h"
#include "token_iterator.h"
#include <iostream>


struct RectType {

  int64_t id;
  int64_t x1;
  int64_t y1;
  int64_t x2;
  int64_t y2;
  int64_t net_id;
  int layer_id;
};

std::istream& operator>>(std::istream& is, RectType& r) {

  std::string line;
  while (std::getline(is, line)) {
    if (!empty_line(line) && !comment_line(line)) break;
  }

  if ( line.size() > 0 ) {

    auto token_it = ns_token::cbegin_token(line);
    auto token_end = ns_token::cend_token(line);
    // id
    if (token_it != token_end) {
      r.id = std::stol(*token_it);
      ++token_it;
    }
    // x1:
    if (token_it != token_end) {
      r.x1 = std::stol(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }


    // y1:
    if (token_it != token_end) {
      r.y1 = std::stol(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }

    // x2:
    if (token_it != token_end) {
      r.x2 = std::stol(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }

    // y2:
    if (token_it != token_end) {
      r.y2 = std::stol(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }

    // net_id:
    if (token_it != token_end) {
      r.net_id = std::stol(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }

    /* layer id */
    if (token_it != token_end) {
      r.layer_id = std::stoi(*token_it);
      ++token_it;
    }else {
      throw std::runtime_error( line + " bad file format!");
    }


  }

  return is;
}

inline std::vector<RectType> read_rect( std::ifstream& ifs ) {
  return std::vector<RectType>((std::istream_iterator<RectType>(ifs)),
			       (std::istream_iterator<RectType>()));
}

#endif
