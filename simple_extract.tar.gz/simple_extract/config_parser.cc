// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "config_parser.h"
#include <fstream>
#include <string>
#include <iterator>
#include <iostream>
#include <stdexcept>
#include "token_iterator.h"

namespace ns_config {
  Config load_config(const std::string& fconfig) {

    std::ifstream ifs(fconfig);
    if(!ifs) {
      std::string err_msg("Cannot open config file ");
      err_msg += fconfig;
      throw std::runtime_error(err_msg);
      
    }
    
    std::string line;
    const std::string delim = " :\t";


    Config conf;

    while (std::getline(ifs, line)) {
      ns_token::const_token_iterator_t begin = 
	ns_token::cbegin_token(line, delim);
      ns_token::const_token_iterator_t end = 
	ns_token::cend_token(line, delim);
      //      std::cout << line << std::endl;
      if (begin != end) {
	
	if (*begin == "design") {
	  conf.input_design_ = *++begin;
	  continue;
	}
	
	if (*begin == "output") {
	  conf.fill_data_ = *++begin;
	  continue;
	}
	
	if (*begin == "rule_file") {
	  conf.rule_ = *++begin;
	  continue;
	}

	if (*begin == "process_file") {
	  conf.process_db_ = *++begin;
	  continue;
	}

	if (*begin == "critical_nets") {
	  ++begin;
	  std::transform(begin, 
			 end, 
			 std::back_inserter(conf.critical_nets_), 
			 [](const std::string& s) { return std::stol(s);});
	  continue;
	}
	
	if (*begin == "power_nets") {
	  conf.power_id_ = std::stol(*++begin);
	  continue;
	}

	if(*begin == "ground_nets") {
	  conf.gnd_id_ = std::stol(*++begin);
	}
      }
    }

    ifs.close();
    return conf;
  }
}
