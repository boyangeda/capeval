// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __BYANG_17_11_JUN_26_2018_RECT_H
#define __BYANG_17_11_JUN_26_2018_RECT_H


#include <iostream>
#include <stdint.h>
#include <string>
#include <iterator>
#include <vector>
#include <functional>
#include <algorithm>
#include <cassert>

struct rect_t
{
  int64_t rect_id;
  int64_t x1;
  int64_t y1;
  int64_t x2;
  int64_t y2;
  int64_t net_id;
  int32_t layer_id;
  bool blockage {false};
  std::string type;

  bool enclose(double x, double y) const {
    return (x >= x1 && 
	    x <= x2 &&
	    y >= y1 && 
	    y <= y2 );
  }

  bool enclose(int64_t x, int64_t y) const {
    return (x >= x1 && 
	    x <= x2 &&
	    y >= y1 && 
	    y <= y2 );
  }

};


inline std::istream& operator>>(std::istream& is, rect_t& r) {
  is >> r.rect_id
     >> r.x1
     >> r.y1
     >> r.x2
     >> r.y2
     >> r.net_id
     >> r.layer_id
     >> r.type;
  r.blockage = false;
  return is;
}


inline std::ostream& operator<<(std::ostream& os, const rect_t& r) {
  os << r.rect_id << ' '
     << r.x1 << ' '
     << r.y1 << ' '
     << r.x2 << ' '
     << r.y2 << ' '
     << r.net_id << ' '
     << r.layer_id << ' ' <<  r.type;
    
  return os;
}


inline bool enclose(const rect_t& r1, const rect_t& r2) {
  
  return (r1.enclose(r2.x1, r2.y1) && 
	  r1.enclose(r2.x2, r2.y1) &&
	  r1.enclose(r2.x2, r2.y2) &&
	  r1.enclose(r2.x1, r2.y2));
  
}


inline std::vector<rect_t>
collect_rects_on_layer (int layer,
                        const std::vector<rect_t>& all) {
  
  std::vector<rect_t> rects;
  
  std::copy_if(all.begin(), all.end(), std::back_inserter(rects),
               [layer](const rect_t& r) { return layer == r.layer_id; });
  
  return rects;
  
}


inline double area_of(const rect_t& r) {
  double area = (r.x2 - r.x1)*(r.y2 - r.y1);
  assert(area > 0.);
  return area;
}



inline bool operator==(const rect_t& r1, const rect_t& r2) {

  return r1.rect_id == r2.rect_id;
}


inline bool operator!=(const rect_t& r1, const rect_t& r2) {
  return !(r1 == r2);
}


namespace std {
  template <> struct hash<rect_t> {
    typedef rect_t argument_type;
    typedef std::size_t result_type;
    result_type operator()(argument_type const& rect) const noexcept {
      return std::hash<int64_t>()(rect.rect_id);
    }
  };
}




#endif /* __BYANG_17_11_JUN_26_2018_RECT_H */
