// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef _CONFIG_PARSER_H_
#define _CONFIG_PARSER_H_

#include <string>
#include <vector>
#include <iostream>

namespace ns_config {

  struct Config
  {

    Config() = default;

    // Config(Config rhs):
    //   input_design_ (std::move (rhs.input_design_)),
    //   fill_data_ (std::move (rhs.fill_data_)),
    //   rule_ (std::move (rhs.rule_)),
    //   process_db_ (std::move (rhs.process_db_)),
    //   critical_nets_ (std::move (rhs.pcritical_nets_)),
    //   power_id_ (rhs.power_id_),
    //   gnd_id_ (rhs.gnd_id_) {}

  Config(Config&& rhs): 
      input_design_ (std::move (rhs.input_design_)),
      fill_data_ (std::move (rhs.fill_data_)),
      rule_ (std::move (rhs.rule_)),
      process_db_ (std::move (rhs.process_db_)),
      critical_nets_ (std::move (rhs.critical_nets_)),
      power_id_ (rhs.power_id_),
      gnd_id_ (rhs.gnd_id_) { }

		    
    const Config& operator=(Config c){

      input_design_ = std::move(c.input_design_);
      fill_data_ = std::move(c.fill_data_);
      rule_ = std::move(c.rule_);
      process_db_ = std::move(c.process_db_);
      critical_nets_ = std::move(c.critical_nets_);

      power_id_ = c.power_id_;
      gnd_id_ = c.gnd_id_;
      return *this;
    }

    std::string input_design_;
    std::string fill_data_;
    std::string rule_;
    std::string process_db_;
    std::vector<int64_t> critical_nets_;
    int64_t power_id_ {0};
    int64_t gnd_id_ {0};

    void print_conf(std::ostream& os) {
      os << "design: " << input_design_ << std::endl;
      os << "fill: " << fill_data_ << std::endl;
      os << "rule: " << rule_ << std::endl;
      os << "process: " << process_db_ << std::endl;
      os << "critical nets: " ;
      for(auto n: critical_nets_) {
	os << n <<", " ;
      }
      os << std::endl;
      os << "PWR: " << power_id_ << std::endl;
      os << "GND: " << gnd_id_ << std::endl;
    }
  };

  
  Config load_config(const std::string& fconfig);
}



#endif
