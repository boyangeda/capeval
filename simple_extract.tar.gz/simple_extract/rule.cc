// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "rule.h"
namespace rule {
  namespace {
    int min_layer_id = 0;
    int max_layer_id = 9;
  }


  int get_min_layer_id() {
    return min_layer_id;
  }

  void set_min_layer_id(int l) {
    min_layer_id = l;
  }


  int get_max_layer_id() {
    return max_layer_id;
  }

  void set_max_layer_id(int l) {
    max_layer_id = l;
  }
  
}
