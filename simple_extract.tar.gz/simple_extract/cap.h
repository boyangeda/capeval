// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __CAP_HER__
#define __CAP_HER__

#include <vector>
#include <utility>
#include <unordered_map>
#include "process_db.h"
#include "gkdtree.h"
#include "rect.h"

typedef GenericKDTree::TreeType<rect_t,
                                0,
                                std::vector<rect_t>::iterator> Tree;


struct LayerLayoutIndex {

  
  std::vector<rect_t> QueryOverlap(const rect_t& w) const {
    std::vector<rect_t> objs;
    query_tree_.QueryOverlappedObjects(w, objs);
    return objs;
  }

  void QueryOverlap(const rect_t& w, std::vector<rect_t>& objs) const {
    query_tree_.QueryOverlappedObjects(w, objs);
  }
    
  
  LayerLayoutIndex(std::vector<rect_t>&& l,
                   Tree&& t,
		   int layer ): 
    layout_(std::move(l)),
    query_tree_(std::move(t)),
    layer_(layer){ }


  LayerLayoutIndex(LayerLayoutIndex&& rhs): 
    layout_ (std::move(rhs.layout_)),
    query_tree_ (std::move(rhs.query_tree_)),
    layer_(rhs.layer_)  {}
  
  LayerLayoutIndex() = delete;
  LayerLayoutIndex(const LayerLayoutIndex&) = delete;
  
  const std::vector<rect_t>& get_layout() const { return layout_;}
  int get_layer() const { return layer_; }

private:

  std::vector<rect_t> layout_;
  Tree query_tree_;
  int layer_;

};


std::vector<LayerLayoutIndex> build_layout_index(std::vector<rect_t>& layout);


typedef std::pair<int64_t, int64_t> NetPair;

inline bool operator== (NetPair a, NetPair b) {
  return 
    (a.first == b.first && a.second == b.second) ||
    (a.first == b.second && a.second == b.first);

}

inline bool operator != (NetPair a, NetPair b) {
  return !(a == b);
}

namespace std {
  template <> struct hash< NetPair > {
    typedef NetPair argument_type;
    typedef std::size_t result_type;
    result_type operator()(argument_type const& net_pair) const noexcept {
      int64_t min = std::min(net_pair.first, net_pair.second);
      int64_t max = net_pair.first + net_pair.second - min;
      return max ^ ((min + 1) << 1);
    }
  };
}



struct extract_x_dir_type{};
struct extract_y_dir_type{};


struct extract_xplus_dir_type : public extract_x_dir_type {};
struct extract_xminus_dir_type : public extract_x_dir_type {};

struct extract_yplus_dir_type :  public extract_y_dir_type {};
struct extract_yminus_dir_type : public extract_y_dir_type {};



inline int64_t directional_space(const rect_t& from, 
				 const rect_t& to, 
				 extract_xplus_dir_type) {
  return to.x1 - from.x2;
}


inline int64_t directional_space(const rect_t& from, 
				 const rect_t& to, 
				 extract_xminus_dir_type) {

  return directional_space(to, from, extract_xplus_dir_type());
}


inline int64_t directional_space(const rect_t& from, 
				 const rect_t& to, 
				 extract_yplus_dir_type) {

  return to.y1 - from.y2;
}


inline int64_t directional_space(const rect_t& from, 
				 const rect_t& to, 
				 extract_yminus_dir_type) {

  return directional_space(to, from, extract_yplus_dir_type());
}





extern int g_x_resolution;
extern int g_y_resolution;
void cap_api_test();

void x_resolution(int r);
void y_resolution(int r);


int x_resolution();
int y_resolution();

#endif
