// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "fringe_cap.h"
#include "rule.h"
#include <thread>
#include <atomic>
#include "console_msg.h"

template <typename dir_type>
bool extract_fringe_cap (const rect_t& r, 
                         int to_layer,
                         const std::vector<LayerLayoutIndex>& layout,
                         std::unordered_map<NetPair, double>& caps,
                         const process_table_t& tbl, const process_table_t& tbl1, 
			 size_t thread_id = 0) {

  
  
  int64_t max_distance = 600;
  //tbl.last_index() + 0.5;

  rect_t window = create_directional_search_window(r, max_distance, dir_type());

  // add real neighbors
  std::vector<rect_t> real_neighbors;
  layout[to_layer].QueryOverlap(window, real_neighbors);
  if (real_neighbors.size() == 0) return true;

  // mark overlapped neighbors as blockage:
  std::for_each(real_neighbors.begin(), real_neighbors.end(),
		[&r](rect_t& rect){
		  if(!(rect.x2 < r.x1 || 
		       rect.x1 > r.x2 ||
		       rect.y2 < r.y1 || 
		       rect.y1 > r.y2)) {
		    rect.blockage = true;
		  }

		});


  // collect blockage;
  std::vector<rect_t> neighbors;
  
  for(int l = r.layer_id; l < to_layer; ++l) {
    layout[l].QueryOverlap(window, neighbors);
  }

  // mark as blockage
  std::for_each (neighbors.begin(), neighbors.end(), 
		 [](rect_t& rect){ rect.blockage = true; });





  // sort blockage and neighbrs
  neighbors.insert(neighbors.end(), real_neighbors.begin(), real_neighbors.end());
  std::sort(neighbors.begin(), neighbors.end(), SortDirectionalType<dir_type>());


  if (neighbors.size() > 0) {
    directional_side_cap_extract<dir_type>(r, neighbors, caps, tbl, tbl1, thread_id);
  }
  return true;
}


bool extract_fringe_cap (const std::vector<LayerLayoutIndex>& layout_index,
			 std::unordered_map<NetPair, double>& caps,
			 std::vector<layer_process_table_t>& proc) {
  

  constexpr size_t thread_thres = 512; // 0.5k
  
  for (auto& l: layout_index) {
    INFO("Extracting fringe cap on layer " << l.get_layer() << " ....");
    //partition the input
    size_t total_r = l.get_layout().size();
    INFO("Total " << total_r << " polygons on layer "<<l.get_layer());
    
    if (ThreadSetting::thread_count() == 1 || total_r < thread_thres) {
      INFO("Warning, single-thread extraction.");
      for(auto& r: l.get_layout()) {
        for(int to_layer = r.layer_id +1; 
            to_layer <= rule::get_max_layer_id();
            ++to_layer){
          const process_table_t& tbl = get_table(r.layer_id,
                                                 to_layer,
                                                 FRINGE_TABLE,
                                                 proc);
          const process_table_t& tbl1 = get_table(to_layer,
                                                  r.layer_id,
                                                  FRINGE_TABLE,
                                                  proc);

          extract_fringe_cap<extract_xplus_dir_type>
            (r, to_layer, layout_index, caps, tbl, tbl1);
          extract_fringe_cap<extract_xminus_dir_type>
            (r, to_layer, layout_index, caps, tbl, tbl1);
          extract_fringe_cap<extract_yplus_dir_type>
            (r, to_layer, layout_index, caps, tbl, tbl1);
          extract_fringe_cap<extract_yminus_dir_type>
            (r, to_layer, layout_index, caps, tbl, tbl1);

        }
      

      }

      
    } else {      // multi-threading
      INFO("Multi-thread extraction.");
      std::unordered_map<NetPair, double> rlt_caps[64];
      std::thread thread[64];
      
      auto const& layout = l.get_layout();

      size_t avg_ele = total_r / ThreadSetting::thread_count();

      std::atomic<size_t>  extracted;
      extracted.store(0);
      auto begin = layout.begin();

      size_t thread_id = 0; 
      for (;thread_id < ThreadSetting::thread_count() - 1;  ++thread_id) {
        
        auto end = begin + avg_ele;

        thread[thread_id] = std::thread
          ([begin, end, &rlt_caps, thread_id, &proc, &extracted, &layout_index](){
              
            size_t extract_local = 0;
            for(auto start = begin; start != end; ++start) {
              
              const rect_t& r = *start;
              for(int to_layer = r.layer_id +1; 
                  to_layer <= rule::get_max_layer_id();
                  ++to_layer){
                const process_table_t& tbl = get_table(r.layer_id,
                                                       to_layer,
                                                       FRINGE_TABLE,
                                                       proc);
                const process_table_t& tbl1 = get_table(to_layer,
                                                        r.layer_id,
                                                        FRINGE_TABLE,
                                                        proc);

                extract_fringe_cap<extract_xplus_dir_type>
                  (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
                extract_fringe_cap<extract_xminus_dir_type>
                  (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
                extract_fringe_cap<extract_yplus_dir_type>
                  (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
                extract_fringe_cap<extract_yminus_dir_type>
                  (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);

              }
              
              ++ extract_local;
            }
            
            extracted += extract_local;
          });
        
        begin = end;
      }

      // last thread
      auto end = layout.end();
      assert(thread_id == ThreadSetting::thread_count() - 1);


      thread[thread_id] = std::thread
        ([begin, end, &rlt_caps, thread_id, &proc, &extracted, &layout_index](){
              
          size_t extract_local = 0;
          for(auto start = begin; start != end; ++start) {
              
            const rect_t& r = *start;
            for(int to_layer = r.layer_id +1; 
                to_layer <= rule::get_max_layer_id();
                ++to_layer){
              const process_table_t& tbl = get_table(r.layer_id,
                                                     to_layer,
                                                     FRINGE_TABLE,
                                                     proc);
              const process_table_t& tbl1 = get_table(to_layer,
                                                      r.layer_id,
                                                      FRINGE_TABLE,
                                                      proc);

              extract_fringe_cap<extract_xplus_dir_type>
                (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
              extract_fringe_cap<extract_xminus_dir_type>
                (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
              extract_fringe_cap<extract_yplus_dir_type>
                (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);
              extract_fringe_cap<extract_yminus_dir_type>
                (r, to_layer, layout_index, rlt_caps[thread_id], tbl, tbl1);

            }
              
            ++ extract_local;
          }
            
          extracted += extract_local;
        });
      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	thread[i].join();
      }

      if(total_r != extracted.load()) {
	ERROR("some rects are skiped.");
	exit(-1);
      }     
      // save results:
      for(size_t i = 0; i < ThreadSetting::thread_count(); ++i) {
	for(auto& c: rlt_caps[i]) {
	  caps[c.first] += c.second;
	}
      }

    }


    INFO("OK");
  }

  return true;
}

			 

