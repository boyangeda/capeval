// Copyright 2018 Bo Yang

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef __FRINGE_CAP_HDR__
#define __FRINGE_CAP_HDR__
#include <vector>
#include <utility>
#include <unordered_map>
#include "process_db.h"
#include "gkdtree.h"
#include "rect.h"
#include "cap.h"
#include <math.h>
#include "mt.h"
#include "console_msg.h"
// x-->
inline rect_t create_directional_search_window(const rect_t& r, 
					       int64_t distance, 
					       extract_xplus_dir_type) {
  rect_t w = r;
  w.x1 = r.x2 + 1;
  w.x2 = r.x2 + distance;
  
  return w;
}



// <---x
inline rect_t create_directional_search_window(const rect_t& r, 
					       int64_t distance, 
					       extract_xminus_dir_type) {
  rect_t w = r;
  w.x2 = r.x1 - 1;
  w.x1 = r.x1 - distance;
  return w;
}


// y-->
inline rect_t create_directional_search_window(const rect_t& r, 
					       int64_t distance, 
					       extract_yplus_dir_type) {
  rect_t w = r;
  w.y1 = r.y2 + 1;
  w.y2 = r.y2 + distance;
  
  return w;
}

// <---y
inline rect_t create_directional_search_window(const rect_t& r, 
					       int64_t distance, 
					       extract_yminus_dir_type) {
  rect_t w = r;
  w.y2 = r.y1 - 1;
  w.y1 = r.y1 - distance;
  return w;
}



inline 
double create_sample_point_between(double a, double b, size_t thread_id) {
  double range = b - a;
  double y = a + range*erand48(ThreadSetting::rand_seed(thread_id));
  return y;
}

inline
double create_sample_point_on(const rect_t& r, extract_x_dir_type, size_t thread_id)  {
  return create_sample_point_between(r.y1, r.y2, thread_id);
}


inline
double create_sample_point_on(const rect_t& r, extract_y_dir_type, size_t thread_id) {
  return create_sample_point_between(r.x1, r.x2, thread_id);
}


inline
bool directional_hit(const rect_t& r, double v, extract_x_dir_type) {
  return (v >= r.y1 && v <= r.y2);
}


inline
bool directional_hit(const rect_t& r, double v, extract_y_dir_type) {
  return (v >= r.x1 && v <= r.x2);
}

inline
bool directional_hit(const rect_t& r, int64_t v, extract_x_dir_type) {
  return (v >= r.y1 && v <= r.y2);
}


inline
bool directional_hit(const rect_t& r, int64_t v, extract_y_dir_type) {
  return (v >= r.x1 && v <= r.x2);
}


inline
size_t directional_edge_length(const rect_t& r, extract_x_dir_type) {
  return r.y2 - r. y1;
}


inline
size_t directional_edge_length(const rect_t& r, extract_y_dir_type) {
  return r.x2 - r. x1;
}



template<typename dir_type>
std::pair<bool, rect_t const*> 
directional_hit(double value, 
		std::vector<rect_t> const& neighbors) {

  for(auto& r: neighbors) {
    if (directional_hit(r, value, dir_type())) {

      if (r.blockage) {		// absorbed by blockage
	return std::make_pair(false, nullptr);
      } else {
	return std::make_pair(true, &r);
      }
    }
  }

  return std::make_pair(false, nullptr);
}

template<typename dir_type>
std::pair<bool, rect_t const*> 
directional_hit(int64_t value, 
		std::vector<rect_t> const& neighbors) {

  for(auto& r: neighbors) {
    if (directional_hit(r, value, dir_type())) {

      if (r.blockage) {		// absorbed by blockage
	return std::make_pair(false, nullptr);
      } else {
	return std::make_pair(true, &r);
      }
    }
  }

  return std::make_pair(false, nullptr);
}


template <typename dir_type>
inline  void side_sample(const rect_t& r, 
			 size_t samples,
			 std::unordered_map<rect_t, double>& hit_map,
			 const std::vector<rect_t>& neighbors,
			 size_t thread_id) {

  for (size_t i = 0; i < samples; ++i) {
    double y = create_sample_point_on(r, dir_type(), thread_id);
    bool hit = false;
    const rect_t* p_hit_rect = nullptr;
    std::tie(hit, p_hit_rect) = directional_hit<dir_type>(y, neighbors);

    if (hit) {
      hit_map[*p_hit_rect] += 1.;
    }

  }

}


inline int directional_resolution(extract_x_dir_type) { 
  return y_resolution(); 
}

inline int directional_resolution(extract_y_dir_type) { 
  return x_resolution(); 
}

inline std::pair<int64_t, int64_t> sample_range(const rect_t& r, 
						extract_x_dir_type) {
  return std::make_pair(r.y1, r.y2);
}


inline std::pair<int64_t, int64_t> sample_range(const rect_t& r, 
						extract_y_dir_type) {
  return std::make_pair(r.x1, r.x2);
}


template <typename dir_type>
inline  size_t static_side_sample(const rect_t& r, 
				  std::unordered_map<rect_t, double>& hit_map,
				  const std::vector<rect_t>& neighbors) {
  int64_t begin = 0;
  int64_t end = 0;
  std::tie(begin, end) = sample_range(r, dir_type());
  size_t total_samples = 0;
  int resolution = directional_resolution(dir_type());

  for(int64_t y = begin; y <= end; y += resolution) {
    ++ total_samples;
    bool hit = false;
    const rect_t* p_hit_rect = nullptr;
    std::tie(hit, p_hit_rect) = directional_hit<dir_type>(y, neighbors);

    if (hit) {
      hit_map[*p_hit_rect] += 1.;
    }
    
  }

  return total_samples;

}

inline double calculate_lateral_cap_helper(double overlap_seg, 
                                           double distance,
                                           const process_table_t& lat_table) {
  
  auto tbl_point = lat_table.query(distance);
  // scale up or down: for lateral, its 0
  if(tbl_point.first != process_table_t::NO_SCALE) return 0;

  return (tbl_point.second.first * distance + tbl_point.second.second) *overlap_seg;
}
		 
		 
template <typename dir_type>
inline 
double calculate_side_total_cap(const rect_t& r,
				const std::unordered_map<rect_t, double>& hit_map, 
				double total_samples,
				double sample_edge_length,
				const process_table_t& tbl) {

  double total_cap = 0.;
  for(auto& hit: hit_map)  {
    double overlap_length = hit.second/total_samples*sample_edge_length;
    double distance = directional_space(r, hit.first, dir_type());
    double cap_val = calculate_lateral_cap_helper(overlap_length, distance, tbl);
    total_cap += cap_val;
  }

  return total_cap;
}



template <typename dir_type> 
inline bool directional_side_cap_extract(const rect_t& r,
					 const std::vector<rect_t>& neighbors,
					 std::unordered_map<NetPair, double>& caps,
					 const process_table_t& tbl,
					 size_t thread_id) {


  



  std::unordered_map<rect_t, double> hit_map;  




  double edge_length = directional_edge_length(r, dir_type());
  double range_length = edge_length;

  size_t total_samples = static_side_sample<dir_type>(r, hit_map, neighbors);
  for(auto& hit: hit_map)  {

    double overlap_length = hit.second/total_samples*range_length;
    double distance = directional_space(r, hit.first, dir_type());
    double cap_val = calculate_lateral_cap_helper(overlap_length, distance, tbl);
    const auto key = std::make_pair(r.net_id, hit.first.net_id);


    if(cap_val < 0) {
      INFO("Warning: negative cap found: " << cap_val);
    }
    caps[key] += cap_val;

  }

  return true;

}


template <typename dir_type> 
inline bool directional_side_cap_extract(const rect_t& r,
					 const std::vector<rect_t>& neighbors,
					 std::unordered_map<NetPair, double>& caps,
					 const process_table_t& tbl, 
					 const process_table_t& tbl_fringe2,
					 size_t thread_id) {


  



  std::unordered_map<rect_t, double> hit_map;  

  // init samples

  double range_length = directional_edge_length(r, dir_type());
  size_t total_samples = static_side_sample<dir_type>(r, hit_map, neighbors);
  for(auto& hit: hit_map)  {

    double overlap_length = hit.second/total_samples*range_length;
    double distance = directional_space(r, hit.first, dir_type());
    double cap_val1 = calculate_lateral_cap_helper(overlap_length, distance, tbl);
    double cap_val2 = calculate_lateral_cap_helper(overlap_length, distance, tbl_fringe2);
    
    caps[std::make_pair(r.net_id, hit.first.net_id)] += (cap_val1 + cap_val2);


  }

  return true;

}

template <typename T> struct SortDirectionalType;

// xplus
template <> struct SortDirectionalType<extract_xplus_dir_type>:
  public std::binary_function<const rect_t, const rect_t, bool> {
  bool operator()(const rect_t& a, const rect_t& b) const {
    return a.x1 < b.x1;
  }
};

// xminus
template <> struct SortDirectionalType<extract_xminus_dir_type>:
  public std::binary_function<const rect_t, const rect_t, bool> {
  bool operator()(const rect_t& a, const rect_t& b) const {
    return a.x2 > b.x2;
  }
};


// yplus
template <> struct SortDirectionalType<extract_yplus_dir_type>:
  public std::binary_function<const rect_t, const rect_t, bool> {
  bool operator()(const rect_t& a, const rect_t& b) const {
    return a.y1 < b.y1;
  }
};

// yminus
template <> struct SortDirectionalType<extract_yminus_dir_type>:
  public std::binary_function<const rect_t, const rect_t, bool> {
  bool operator()(const rect_t& a, const rect_t& b) const {
    return a.y2 > b.y2;
  }
};






bool extract_fringe_cap (const std::vector<LayerLayoutIndex>& layout,
			 std::unordered_map<NetPair, double>& caps,
			 std::vector<layer_process_table_t>& proc) ;

bool extract_fringe_cap (const rect_t& r,
			 const std::vector<LayerLayoutIndex>& layout,
			 std::unordered_map<NetPair, double>& caps,
			 const process_table_t& fringe_tbl);


#endif

